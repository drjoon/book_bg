export const API_BASE_URL = import.meta.env.DEV
  ? "http://localhost:8081"
  : "http://golf-book.ap-south-1.elasticbeanstalk.com";
